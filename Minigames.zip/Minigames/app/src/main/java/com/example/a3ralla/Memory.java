package com.example.a3ralla;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import android.widget.Toast;


public class Memory extends AppCompatActivity {


    ImageButton imb00, imb01, imb02, imb03, imb04, imb05, imb06, imb07, imb08, imb09, imb10, imb11, imb12, imb13, imb14, imb15;

    ImageButton[] tauler = new ImageButton[16];

    Button btn_reiniciar, btn_sortir;

    TextView txt_puntuacio;
    TextView txt_torns;
    int puntuacio, encerts, fondo;

    int[] imatges;
    private int numTorns = 0;


    ArrayList<Integer> arrayDesordre;
    ImageButton primer;

    int num_primer, num_segon;

    boolean bloc= false;

    final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memory);  // Change to the correct layout name
        init();
    }


    private void carregarTauler() {
        imb00 = findViewById(R.id.imgBtn00);
        imb01 = findViewById(R.id.imgBtn01);
        imb02 = findViewById(R.id.imgBtn02);
        imb03 = findViewById(R.id.imgBtn03);
        imb04 = findViewById(R.id.imgBtn04);
        imb05 = findViewById(R.id.imgBtn05);
        imb06 = findViewById(R.id.imgBtn06);
        imb07 = findViewById(R.id.imgBtn07);
        imb08 = findViewById(R.id.imgBtn08);
        imb09 = findViewById(R.id.imgBtn09);
        imb10 = findViewById(R.id.imgBtn10);
        imb11 = findViewById(R.id.imgBtn11);
        imb12 = findViewById(R.id.imgBtn12);
        imb13 = findViewById(R.id.imgBtn13);
        imb14 = findViewById(R.id.imgBtn14);
        imb15 = findViewById(R.id.imgBtn15);

        tauler[0] = imb00;
        tauler[1] = imb01;
        tauler[2] = imb02;
        tauler[3] = imb03;
        tauler[4] = imb04;
        tauler[5] = imb05;
        tauler[6] = imb06;
        tauler[7] = imb07;
        tauler[8] = imb08;
        tauler[9] = imb09;
        tauler[10] = imb10;
        tauler[11] = imb11;
        tauler[12] = imb12;
        tauler[13] = imb13;
        tauler[14] = imb14;
        tauler[15] = imb15;
    }


    private void carregarBtn(){
        btn_reiniciar = findViewById(R.id.btnreiniciar);
        btn_sortir = findViewById(R.id.btnsortir);

        btn_reiniciar.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                init();
            }
        });
    }

    private void carregarTxt(){
        txt_puntuacio = findViewById(R.id.txtPuntuacio);
        puntuacio = 0;
        encerts = 0;
        txt_puntuacio.setText("Punctuation: " + puntuacio);

        txt_torns = findViewById(R.id.txtTorns);
        txt_puntuacio.setText("turns: " + numTorns );
    }


    private void carregarImg(){
        imatges =new int []{
                R.drawable.la0,
                R.drawable.la1,
                R.drawable.la2,
                R.drawable.la3,
                R.drawable.la4,
                R.drawable.la5,
                R.drawable.la6,
                R.drawable.la7

        };
        fondo = R.drawable.fondo;
    }

    private ArrayList<Integer> barajar(int longitud){
        ArrayList<Integer> result = new ArrayList<>();
        for (int i=0; i<longitud*2; i++){
            result.add(i % longitud);
        }
        Collections.shuffle(result);
        System.out.println(Arrays.toString(result.toArray()));
        return result;
    }
    private void comprovar(int i, final ImageButton imgb) {
        if (primer == null) {
            primer = imgb;
            primer.setScaleType(ImageView.ScaleType.CENTER_CROP);
            primer.setImageResource(imatges[arrayDesordre.get(i)]);
            primer.setEnabled(false);
            num_primer = arrayDesordre.get(i);
        } else {
            bloc = true;
            imgb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imgb.setImageResource(imatges[arrayDesordre.get(i)]);
            imgb.setEnabled(false);
            num_segon = arrayDesordre.get(i);
            if (num_primer == num_segon) {
                primer = null;
                bloc = false;
                encerts++;
                puntuacio += 5;  // Increase score by 5 for each correct guess
                txt_puntuacio.setText("Punctuation: " + puntuacio);
            } else {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        primer.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        primer.setImageResource(fondo);
                        primer.setEnabled(true);
                        imgb.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        imgb.setImageResource(fondo);
                        imgb.setEnabled(true);
                        bloc = false;
                        primer = null;
                        puntuacio = Math.max(0, puntuacio - 3);  // Decrement by 1, but not below 0
                        txt_puntuacio.setText("Punctuation: " + puntuacio);
                        if (encerts == imatges.length) {
                            Toast toast = Toast.makeText(getApplicationContext(), "You won!!", Toast.LENGTH_LONG);
                            toast.show();
                        }
                    }
                }, 500);
            }
        }
    }
    private void reiniciarJoc() {
        // Reset game state variables
        encerts = 0;
        puntuacio = 0;
        numTorns = 0;  // Reinicia el comptador de torns
        txt_puntuacio.setText("Punctuation: " + puntuacio + " - turns: " + numTorns);

        // Shuffle and reset card images
        arrayDesordre = barajar(imatges.length);
        for (int i = 0; i < tauler.length; i++) {
            tauler[i].setScaleType(ImageView.ScaleType.CENTER_CROP);
            tauler[i].setImageResource(imatges[arrayDesordre.get(i)]);
            tauler[i].setEnabled(true);
        }

        // Reset the handler delayed task to hide the cards
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < tauler.length; i++) {
                    tauler[i].setScaleType(ImageView.ScaleType.CENTER_CROP);
                    tauler[i].setImageResource(fondo);
                }
            }
        }, 500);
    }

    private void init (){
        carregarTauler();
        carregarBtn();
        carregarImg();
        carregarTxt();
        arrayDesordre = barajar(imatges.length);

        primer = tauler[0];

        for (int i=0; i<tauler.length; i++){
            tauler[i].setScaleType(ImageView.ScaleType.CENTER_CROP);
            tauler[i].setImageResource(imatges[arrayDesordre.get(i)]);
        }

        handler.postDelayed(new Runnable(){
            @Override
            public void run() {
                for (int i=0; i<tauler.length; i++){
                    tauler[i].setScaleType(ImageView.ScaleType.CENTER_CROP);
                    tauler[i].setImageResource(fondo);
                }
            }
        },500);
        for(int i=0;i< tauler.length; i++){
            final int j = i;
            tauler[i].setEnabled(true);
            tauler[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(!bloc){
                        comprovar(j, tauler[j]);
                        numTorns++;  // Incrementa el nombre de torns
                        // Actualitza la puntuació mostrada
                        txt_puntuacio.setText("Punctuation: " + puntuacio + " - Turns: " + numTorns/2);
                    }
                }
            });
        }
        btn_reiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reiniciarJoc();
            }
        });

        btn_sortir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }

}
