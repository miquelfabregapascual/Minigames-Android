package com.example.a3ralla;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;

import java.util.Arrays;
import java.util.Random;
import android.graphics.Color;

import androidx.appcompat.app.AppCompatActivity;




public class Tictactoe extends AppCompatActivity {
    Integer[] botons;
    private int victories = 0;
    private int empats = 0;
    private int derrotes = 0;
    int[]taula=new int[]{
            0,0,0,
            0,0,0,
            0,0,0
    };
    private TextView resultTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activit_tictactoe);
        botons = new Integer[]{
                R.id.button2, R.id.button3, R.id.button4,
                R.id.button5, R.id.button6, R.id.button7,
                R.id.button8, R.id.button9, R.id.button10
        };
        // Inicializa los elementos de la interfaz de usuario
        resultTextView = findViewById(R.id.resultTextView);

        // Get a reference to the "Sortir" button
        Button sortirButton = findViewById(R.id.btn_sortir_tictactoe);

        // Set a click listener for the "Sortir" button
        sortirButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finish the current activity when the button is clicked
                finish();
            }
        });
    }


    public void posarFitxa(View v) {
        int numBtn = Arrays.asList(botons).indexOf(v.getId());
        if (taula[numBtn] == 0) {
            v.setBackgroundResource(R.drawable.x);
            taula[numBtn] = 1;

            if (comprovarGanador(1)) {
                resultTextView.setText("You won!");
                victories++; // Incrementa la puntuación de victorias
                deshabilitarBotons();
            } else if (Empat()) {
                resultTextView.setText("Draw!");
                empats++; // Incrementa la puntuación de victorias
                deshabilitarBotons();
            } else {
                ia();
                if (comprovarGanador(-1)) {
                    resultTextView.setText("The AI won.");
                    derrotes++; // Incrementa la puntuación de victorias
                    deshabilitarBotons();
                }
            }
        }
    }

    public void ia(){
        Random random=new Random();
        int pos=random.nextInt(taula.length);
        while (taula[pos]!=0){
            pos= random.nextInt(taula.length);
        }
        Button btn=(Button) findViewById(botons[pos]);
        btn.setBackgroundResource(R.drawable.o);
        taula[pos]=-1;
    }
    private boolean comprovarGanador(int jugador) {
        // Comprova les files
        for (int i = 0; i < 3; i++) {
            if (taula[i * 3] == jugador && taula[i * 3 + 1] == jugador && taula[i * 3 + 2] == jugador) {
                return true; // Guanya en fila
            }
        }

        // Comprova les columnes
        for (int i = 0; i < 3; i++) {
            if (taula[i] == jugador && taula[i + 3] == jugador && taula[i + 6] == jugador) {
                return true; // Guanya en columa
            }
        }

        // Comprova les diagonals
        if (taula[0] == jugador && taula[4] == jugador && taula[8] == jugador) {
            return true; // Guanya en diagonal
        }
        if (taula[2] == jugador && taula[4] == jugador && taula[6] == jugador) {
            return true; // Guanyador en diagonal 2
        }

        return false; // No hi ha guanyador
    }
    private boolean Empat() {
        for (int i = 0; i < taula.length; i++) {
            if (taula[i] == 0) {
                return false; // Todavía hay celdas vacías, no es un empate.
            }
        }
        return true; // Todas las celdas están ocupadas, es un empate.
    }
    private void deshabilitarBotons() {
        for (int i = 0; i < botons.length; i++) {
            Button btn = findViewById(botons[i]);
            btn.setEnabled(false);
        }
    }
    // Inside your reiniciarPartida method
    public void reiniciarPartida(View view) {
        // Reinicia el estado del juego
        for (int i = 0; i < taula.length; i++) {
            taula[i] = 0;
            Button btn = findViewById(botons[i]);
            btn.setBackgroundColor(Color.parseColor("#016E7C")); // Set the background color
            btn.setEnabled(true); // Habilita los botones nuevamente
            btn.requestLayout();
            btn.invalidate();
        }
        resultTextView.setText(""); // Borra el texto del resultado
        actualizarPuntuaciones();
    }








    // Método para actualizar las puntuaciones en TextViews
    private void actualizarPuntuaciones() {
        TextView victoriesTextView = findViewById(R.id.resultTextView); // Reemplaza con el ID real del TextView
        victoriesTextView.setText("Victòries: " + victories);

        TextView empatsTextView = findViewById(R.id.resultEmpats); // Reemplaza con el ID real del TextView
        empatsTextView.setText("Empats: " + empats);

        TextView derrotesTextView = findViewById(R.id.resultDerrotes); // Reemplaza con el ID real del TextView
        derrotesTextView.setText("Derrotes: " + derrotes);
    }
}
