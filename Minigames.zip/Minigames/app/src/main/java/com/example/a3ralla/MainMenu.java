package com.example.a3ralla;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void launchMemoryGame(View view) {
        Intent intent = new Intent(this, Memory.class);
        startActivity(intent);
    }

    public void launchTresEnRatllaGame(View view) {
        Intent intent = new Intent(this, Tictactoe.class);
        startActivity(intent);
    }
}